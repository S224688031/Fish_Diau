﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HttpRequest : System.Web.UI.Page
{
    //client 使用者輸入   server 程式
    protected void Page_Load(object sender, EventArgs e)
    {   //Request.QueryString會抓往client端輸入的網址後面的一串參數
        TextBox1.Text = Request.QueryString["a"];//a 是參數名稱 隨便你設
    }
}